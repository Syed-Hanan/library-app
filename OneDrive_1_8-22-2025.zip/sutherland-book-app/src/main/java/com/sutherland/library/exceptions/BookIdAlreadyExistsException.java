package com.sutherland.library.exceptions;

@SuppressWarnings("serial")
public class BookIdAlreadyExistsException extends RuntimeException{
	public BookIdAlreadyExistsException(String mesg) {
		super(mesg);
	}
}
