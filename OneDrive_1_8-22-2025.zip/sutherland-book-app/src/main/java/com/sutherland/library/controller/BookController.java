package com.sutherland.library.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sutherland.library.entity.Book;
import com.sutherland.library.service.BookService;

@RestController
@RequestMapping("/book")
@CrossOrigin(origins = "http://localhost:3000")
public class BookController {
	Logger logger = LoggerFactory.getLogger(BookController.class);
	@Autowired
	BookService service;
	
	@PostMapping
	public ResponseEntity<String> addBook(@RequestBody Book book) {
		service.addBook(book);
		return new ResponseEntity<String>("book inserted",HttpStatus.OK);
	}
	
	@PutMapping
	public ResponseEntity<String> editBook(@RequestBody Book book) {
		service.updateBook(book); 
		return new ResponseEntity<String>("book updated",HttpStatus.OK);
	}
	
	@DeleteMapping("/{bookId}")
	public ResponseEntity<String> deleteBook(@PathVariable int bookId){
		service.deleteBook(bookId);
		return new ResponseEntity<String>("deleted",HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Book>> getAllBooks(){
		logger.info("inside getAllBooks"); 
		return new ResponseEntity<List<Book>>(service.getAllBooks(),HttpStatus.OK);
	}
	@GetMapping("/byid/{bookid}")
	public Book getBookById(@PathVariable int bookid) {
		logger.info("inside getBookById");
		return service.getBookById(bookid);
	}
	
	
}
