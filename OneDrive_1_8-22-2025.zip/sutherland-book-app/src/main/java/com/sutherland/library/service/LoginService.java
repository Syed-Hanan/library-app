package com.sutherland.library.service;

import com.sutherland.library.entity.Login;

public interface LoginService {
	void addUser(Login user);
	Login userValidation(Login user);
}
