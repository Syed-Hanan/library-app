package com.sutherland.library.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sutherland.library.entity.Login;
import com.sutherland.library.service.LoginService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = {"http://localhost:3000"})
public class LoginController {
	@Autowired
	LoginService service;
	
	@PostMapping
	public ResponseEntity<String> addUser(@RequestBody Login user) {
		service.addUser(user);
		return new ResponseEntity<String>("user created... ",HttpStatus.OK);
	}
	
	@PostMapping("/validate")
	public ResponseEntity<Login> loginValidate(@RequestBody Login user){
		Login u = service.userValidation(user);
		
		return new ResponseEntity<Login>(u,HttpStatus.OK);
	}
	@GetMapping("/logout")
	public String logout() {
	
		return "Session invalidated";
	}
}
