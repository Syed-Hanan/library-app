package com.sutherland.library.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sutherland.library.entity.Login;
import com.sutherland.library.exceptions.UserNotFoundException;


@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	com.sutherland.library.repo.LoginRepository repo;
	
	@Override
	public void addUser(Login user) {
		repo.save(user);		
	}

	@Override
	public Login userValidation(Login user) {
			Optional<Login> opUser= repo.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		if(opUser.isEmpty())
			throw new UserNotFoundException();
		return opUser.get();
	}

}
