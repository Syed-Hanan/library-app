import React, { useState } from 'react'
import BookService from '../service/BookService'
import { Link, useNavigate } from 'react-router-dom';

function AddBook() {
    const service = BookService();
    const [book, setBook] = useState({
        bookId : 0
    });
    const navigate = useNavigate();

    const changeData = (obj) => {
        setBook({...book, [obj.target.name] : obj.target.value});
    }

    const submitData = (event) => {
        event.preventDefault();
        if(book.bookId===0 || book.bookId.length===0)
            alert("Invalid book id");
        else {
         service.addBook(book);
         navigate('/getallbooks')
        }
    }
  return (
    <div className="align-items-center container">
        <h1>Add new Book</h1> 
        <form>
            <div className="form-group justify-content-center">
            <label>Enter Book ID</label>
            <input  type='text' name='bookId' value={book.bookId}  
                    onChange={changeData} className='form-control'required/>
             <label>Enter Book Title</label>
            <input  type='text' name='title' value={book.title}  
                    onChange={changeData} className='form-control'/>
             <label>Enter Book Author</label>
            <input  type='text' name='author' value={book.author}  
                    onChange={changeData} className='form-control'/>
             <label>Enter Publications</label>
            <input  type='text' name='publisher' value={book.publisher}  
                    onChange={changeData} className='form-control'/>
             <label>Enter Book Price</label>
            <input  type='text' name='price' value={book.price}  
                    onChange={changeData} className='form-control'/>

            <button className="ui button medium green" onClick={submitData}>Add </button>  &nbsp;&nbsp;
            <Link to={"/getallbooks"}> 
                        <button className="ui primary button medium">Cancel</button>
                    </Link>
            </div>
        </form>
  </div>
  )
}

export default AddBook