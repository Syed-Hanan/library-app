package com.sutherland.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SutherlandLibraryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SutherlandLibraryAppApplication.class, args);
	}

}
