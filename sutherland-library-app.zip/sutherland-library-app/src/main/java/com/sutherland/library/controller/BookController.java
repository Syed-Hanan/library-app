package com.sutherland.library.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sutherland.library.entity.Book;
import com.sutherland.library.service.BookService;

@RestController
@RequestMapping("/book")
public class BookController {
	@Autowired
	BookService service;
	
	@PostMapping
	public ResponseEntity<String> addBook(@RequestBody Book book) {
		service.addBook(book);
		return new ResponseEntity<String>("book inserted",HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Book>> getAllBooks(){
		return new ResponseEntity<List<Book>>(service.getAllBooks(),HttpStatus.OK);
	}
	@GetMapping("/byid/{bookid}")
	public Book getBookById(@PathVariable int bookid) {
		return service.getBookById(bookid);
	}
}
